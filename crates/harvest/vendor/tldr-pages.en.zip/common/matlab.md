# matlab

> Numerical computation environment by MathWorks.
> More information: <https://www.mathworks.com/help/matlab/matlab_env/startup-options/>.

- Run without splash screen during startup:

`matlab -nosplash`

- Execute a MATLAB statement:

`matlab -r "{{matlab_statement}}"`

- Run a MATLAB script:

`matlab -r "run({{path/to/script.m}})"`
